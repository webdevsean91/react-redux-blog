import React from 'react';

export default () => {
  return (
    <footer className="footer">
      <div className="container">
        <span className="text-muted">@2017 Haichao Yu</span>
      </div>
    </footer>
  );
}